
estoque = []

def adicionar(porta):
    estoque.append(porta)

def imprimir_estoque():
    for porta in estoque:
        print(porta)

