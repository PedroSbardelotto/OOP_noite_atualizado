class Caixa:
    def __init__(self, nome, id):
        self.nome = nome
        self.id = id
        self.chave = True
        self.controle_proj = True
        # self.status = False | # true locada false ta estante 
        