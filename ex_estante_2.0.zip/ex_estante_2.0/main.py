class Caixa:
    def __init__(self):
        self.qnt_canetas = 5
        self.numero_caixa = 703
        self.chave = True
        self.controle_proj = True

    def Conferir(self):
        pass

    def Imprimir(self):
        pass







